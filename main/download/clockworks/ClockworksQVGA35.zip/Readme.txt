Clockworks
By Gunther Willems

Homepage: http://users.skynet.be/gunther.willems/clockworks/index.html

This is a widget of an analogue clock with clockworks visible for use with Spb Mobile Shell 3.5 on a Windows Mobile smartphone.

Automatic installation:
-----------------------

Copy all the files from this .zip file in the SPB Mobile shell folder (on the device)
Also copy the subfolder "InstallClockworks" with its files
ex. \program files\Spb Mobile Shell
Start / Programs / File Explorer
Goto the folder \program files\Spb Mobile Shell\InstallClockworks
Click on MortScript.exe, click ok (.mscr and .mortrun will be registered)
Click on Install_Clockworks.mscr
Installation done, click ok

Mobile Shell is automatically restarted. You can directly use the new clocks.


Manual installation:
--------------------

How to use the files inside the compressed .zip file:
Copy all the files with extension .dat in the Mobile Shell program folder on the smartphone:
Folder: \Program Files\Spb Mobile Shell

Add the file Clockworks.xml inside the \Program Files\Spb Mobile Shell\qa_layouts.dat file. This is a .zip compressed file with password: b0fm18zq
Rename the .zip extension to .dat

Import this file into the registery of the smartphone: Clockworks(Q)VGA35.reg

For the changes to take effect, quit "Mobile Shell" or soft reset the smartphone.
