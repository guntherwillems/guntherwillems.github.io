This is the README file for the 17 August 1999 release
of "Expression Calculator" Version 1.3

ExpCalc.exe   : Main program
ExpGraph.exe  : 2D graphics program
ExpCalc.hlp   : Help file
ExpCalc.cnt   : Help file table of contents
ExpCalc.ini   : Some example functions and values
Readme.txt    : This text


GENERAL INFO
------------

With the calculator you can:
- Calculate expressions of an infinite length and complexity.
- Store an infinite number of lines containing expressions for reference or
  later use.
- Create an infinite number of user variables.
- Create an infinite number of user functions with up to three parameters.
- Save all the preceding possibilities for later use.

- Draw two-dimensional graphics.

Infinite means as long as your memory can support it.


SYSTEM REQUIREMENTS
-------------------

- Windows 95
- Windows 98
- Winodws Me
- Windows NT 4.0
- Windows 2000
- WIndows XP
 


CHANGES AND NEW FEATURES
------------------------

Version 1.0 : april 1999
  First release
Version 1.1 : september 2000
  Minimize with standard Windows effect.
  No more Run-time package needed.
Version 1.2 : July 2001
  Compiled with the latest patched compiler.
  Shrink - Expand button.
version 1.3 : december 2001
  Compatibility with Windows XP interface
  'Calculate' now is the default button


INTERNET RESOURCES
------------------

The URL of the homepage is http://www.geocities.com/willemsgunther
A redirector is available, in case this site ever moves to a different server:
http://go.to/expcalc

When a serious problem has been found, send me a mail, including the way to 
reproduce the problem/bug.

E-mail address  : expcalc@go.to
Please use "ExpCalc" as the subject.


COPYRIGHT
---------

IF YOU DO NOT AGREE TO THE TERMS OF THIS AGREEMENT, DO NOT USE THIS SOFTWARE. 
PROMPTLY REMOVE IT FROM YOUR COMPUTER.

"Expression Calculator" is owned by WILLEMS Gunther. The software and 
documentation may be re-distributed in its entirety and unmodified. 
"Expression Calculator" is free for personal use only.  It may not be 
distributed (with or without other products) for profit without the author's 
expressed written permission.

NO WARRANTY: Any use of the Software is at your own risk. 
